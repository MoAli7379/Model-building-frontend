import React from 'react';
import GridComponent from '../GridComponent';

const columnDefs = [
  { label: 'File', field: 'file' },
  { label: 'Uploaded At', field: 'uploaded_at' },
];

const CsvFilesPage: React.FC = () => {
  const endpoint = "/api/csv_files";

  const handleRowSelection = (selectedRows: any[]) => {
    console.log(selectedRows);
  };

  return (
    <GridComponent endpoint={endpoint} columns={columnDefs} onRowSelection={handleRowSelection} />
  );
};

export default CsvFilesPage;
