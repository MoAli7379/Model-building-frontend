import React, { useState } from 'react';
import GridComponent from '../GridComponent';
import ReusableModal from '../components/ReusableModal';

interface Model {
  id: number;
  name: string;
  model_type?: string;
  created_at?: string;
  accuracy?: number | null;
  is_active?: boolean;
}

interface ModelPageProps {
  onModelSelect: (model: Model) => void;
}

const columnDefs = [
  { label: 'Name', field: 'name' },
  { label: 'Type', field: 'model_type' },
  { label: 'Created At', field: 'created_at' },
  { label: 'Accuracy', field: 'accuracy' },
];

const ModelPage: React.FC<ModelPageProps> = ({ onModelSelect }) => {
  const [selectedModel, setSelectedModel] = useState<Model | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleRowSelection = (selectedRows: Model[]) => {
    if (selectedRows.length > 0) {
      const model = selectedRows[0];
      setSelectedModel(model);
      setIsModalOpen(true);
      onModelSelect(model);
    }
  };

  const modalConfig = [
    { label: 'Name', field: 'name' },
    { label: 'Type', field: 'model_type' },
    { label: 'Created At', field: 'created_at' },
    { label: 'Accuracy', field: 'accuracy' },
  ];

  return (
    <>
      <GridComponent endpoint="/ai/ai_models" columns={columnDefs} onRowSelection={handleRowSelection} />
      {selectedModel && (
        <ReusableModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          title="Model Details"
          endpoint={`/ai/ai_models/${selectedModel.id}`}
          config={modalConfig}
        />
      )}
    </>
  );
};

export default ModelPage;
