import React, { useState } from 'react';
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  Button,
  FormControl,
  FormLabel,
  Select,
  Switch,
  useToast,
  Flex,
  Box,
  Text,
} from '@chakra-ui/react';
import ModelSelectionModal from './ModelSelectionModal';

interface GameConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfigApply: (config: {
    player_white: string;
    player_black: string;
    save_data: boolean;
    model_white?: { id: number; name: string };
    model_black?: { id: number; name: string };
  }) => void;
}

interface Model {
  id: number;
  name: string;
}

const PLAYER_TYPE_CHOICES = [
  { value: 'Player', label: 'Player' },
  { value: 'Heuristic', label: 'Heuristic' },
  { value: 'Model', label: 'Model' },
];

const GameConfigModal: React.FC<GameConfigModalProps> = ({ isOpen, onClose, onConfigApply }) => {
  const [playerWhite, setPlayerWhite] = useState<string>('Player');
  const [playerBlack, setPlayerBlack] = useState<string>('Player');
  const [saveData, setSaveData] = useState<boolean>(true);
  const [modelWhite, setModelWhite] = useState<Model | null>(null);
  const [modelBlack, setModelBlack] = useState<Model | null>(null);
  const [isModelSelectionModalOpen, setModelSelectionModalOpen] = useState<boolean>(false);
  const [currentModelPlayer, setCurrentModelPlayer] = useState<string | null>(null);
  const toast = useToast();

  const handleApply = () => {
    const config = {
      player_white: playerWhite,
      player_black: playerBlack,
      save_data: saveData,
      model_white: playerWhite === 'Model' && modelWhite ? { id: modelWhite.id, name: modelWhite.name } : undefined,
      model_black: playerBlack === 'Model' && modelBlack ? { id: modelBlack.id, name: modelBlack.name } : undefined,
    };

    if ((playerWhite === 'Model' && !modelWhite) || (playerBlack === 'Model' && !modelBlack)) {
      toast({
        title: 'Error',
        description: 'Please select models for both players if "Model" is chosen.',
        status: 'error',
        duration: 5000,
        isClosable: true,
      });
      return;
    }

    if (config.model_white) {
      fetch('http://127.0.0.1:8000/ai/update_model/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model_pk: config.model_white.id, player: 'white' }),
      }).catch((error) => {
        console.error('Error applying white model:', error);
      });
    }

    if (config.model_black) {
      fetch('http://127.0.0.1:8000/ai/update_model/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model_pk: config.model_black.id, player: 'black' }),
      }).catch((error) => {
        console.error('Error applying black model:', error);
      });
    }

    onConfigApply(config);
  };

  const openModelSelection = (player: string) => {
    setCurrentModelPlayer(player);
    setModelSelectionModalOpen(true);
  };

  const handleModelSelect = (model: { id: number; name: string }) => {
    if (currentModelPlayer === 'white') {
      setModelWhite(model);
    } else if (currentModelPlayer === 'black') {
      setModelBlack(model);
    }
    setModelSelectionModalOpen(false);
  };

  return (
    <>
      <Modal isOpen={isOpen} onClose={onClose} size="xl">
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Configure Game</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Flex direction="column" gap={4}>
              <Flex direction="column" overflow="auto" maxH="100vh" p={4}>
                  <Flex direction="row" gap={4} overflow="auto">
                    <Box flex="1">
                      <FormControl>
                        <FormLabel>Player White</FormLabel>
                        <Select value={playerWhite} onChange={(e) => setPlayerWhite(e.target.value)}>
                          {PLAYER_TYPE_CHOICES.map((choice) => (
                            <option key={choice.value} value={choice.value}>
                              {choice.label}
                            </option>
                          ))}
                        </Select>
                      </FormControl>
                      {playerWhite === 'Model' && (
                        <>
                          <Button
                            mt={4}
                            onClick={() => openModelSelection('white')}
                            colorScheme="blue"
                            width="full"
                          >
                            Select Model for White
                          </Button>
                          {modelWhite && <Text mt={2}>Selected Model: {modelWhite.name}</Text>}
                        </>
                      )}
                    </Box>
                    <Box flex="1">
                      <FormControl>
                        <FormLabel>Player Black</FormLabel>
                        <Select value={playerBlack} onChange={(e) => setPlayerBlack(e.target.value)}>
                          {PLAYER_TYPE_CHOICES.map((choice) => (
                            <option key={choice.value} value={choice.value}>
                              {choice.label}
                            </option>
                          ))}
                        </Select>
                      </FormControl>
                      {playerBlack === 'Model' && (
                        <>
                          <Button
                            mt={4}
                            onClick={() => openModelSelection('black')}
                            colorScheme="blue"
                            width="full"
                          >
                            Select Model for Black
                          </Button>
                          {/* {modelBlack && <Text mt={2}>Selected Model: {modelBlack.name}</Text>} */}
                        </>
                      )}
                    </Box>
                  </Flex>
                </Flex>
              <FormControl display="flex" alignItems="center" mt={4}>
                <FormLabel htmlFor="save-data" mb="0">
                  Save Data
                </FormLabel>
                <Switch id="save-data" isChecked={saveData} onChange={(e) => setSaveData(e.target.checked)} />
              </FormControl>
            </Flex>
          </ModalBody>
          <ModalFooter>
            <Button colorScheme="blue" onClick={handleApply}>
              Apply
            </Button>
            <Button ml={3} onClick={onClose}>
              Close
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
      <ModelSelectionModal
        isOpen={isModelSelectionModalOpen}
        onClose={() => setModelSelectionModalOpen(false)}
        onModelSelect={handleModelSelect}
        currentModelPlayer={currentModelPlayer}
      />
    </>
  );
};

export default GameConfigModal;
