import React, { useState } from 'react';
import {
  Box,
  FormControl,
  FormLabel,
  Input,
  NumberInput,
  NumberInputField,
  Checkbox,
  Button,
  Tooltip,
  useToast,
  Text,
  Stack,
  Alert,
  AlertIcon,
  AlertDescription,
  SimpleGrid,
  VStack,
  Heading,
  Divider,
  Icon,
  useColorModeValue,
  Accordion,
  AccordionItem,
  AccordionButton,
  AccordionPanel,
  AccordionIcon,
} from '@chakra-ui/react';
import { FaLightbulb, FaRobot, FaInfoCircle } from 'react-icons/fa';

interface AlgorithmParameter {
  label: string;
  type: 'number' | 'text' | 'boolean';
  defaultValue: number | string | boolean;
  description: string;
}

interface AlgorithmParameters {
  [key: string]: AlgorithmParameter[];
}

const algorithmParams: AlgorithmParameters = {
  "Linear Regression": [
    { label: "Intercept", type: "boolean", defaultValue: true, description: "Should the model calculate the intercept for this regression?" },
    { label: "Normalize", type: "boolean", defaultValue: false, description: "Should the regressors X be normalized before regression?" }
  ],
  "Polynomial Regression": [
    { label: "Degree", type: "number", defaultValue: 2, description: "The degree of the polynomial features." },
    { label: "Include Bias", type: "boolean", defaultValue: true, description: "Include a bias column in the feature matrix." },
    { label: "Interaction Only", type: "boolean", defaultValue: false, description: "Produce only interaction features." }
  ],
  "Ridge Regression": [
    { label: "Alpha", type: "number", defaultValue: 1.0, description: "Regularization strength; must be a positive float." },
    { label: "Solver", type: "text", defaultValue: "auto", description: "Solver to use in the computational routines." }
  ],
  "Lasso Regression": [
    { label: "Alpha", type: "number", defaultValue: 1.0, description: "Regularization strength; must be a positive float." },
    { label: "Max Iterations", type: "number", defaultValue: 1000, description: "The maximum number of iterations." }
  ],
  "Elastic Net": [
    { label: "Alpha", type: "number", defaultValue: 1.0, description: "Constant that multiplies the penalty terms." },
    { label: "L1 Ratio", type: "number", defaultValue: 0.5, description: "The ElasticNet mixing parameter, with 0 <= l1_ratio <= 1." }
  ],
  "Decision Tree": [
    { label: "Max Depth", type: "number", defaultValue: 10, description: "The maximum depth of the tree." },
    { label: "Min Samples Split", type: "number", defaultValue: 2, description: "The minimum number of samples required to split an internal node." }
  ],
  "SVR": [
    { label: "Kernel", type: "text", defaultValue: "rbf", description: "Specifies the kernel type to be used in the algorithm." },
    { label: "Degree", type: "number", defaultValue: 3, description: "Degree of the polynomial kernel function." },
    { label: "C", type: "number", defaultValue: 1.0, description: "Regularization parameter. The strength of the regularization is inversely proportional to C." },
    { label: "Epsilon", type: "number", defaultValue: 0.1, description: "Epsilon in the epsilon-SVR model." }
  ],
  "Random Forest": [
    { label: "Number of Estimators", type: "number", defaultValue: 100, description: "The number of trees in the forest." },
    { label: "Max Depth", type: "number", defaultValue: 10, description: "The maximum depth of the tree." }
  ]
};

const AlgorithmDetails: React.FC<{ algorithm: string }> = ({ algorithm }) => {
  const [params, setParams] = useState<{[key: string]: number | string | boolean}>(() => {
    const initParams: {[key: string]: number | string | boolean} = {};
    algorithmParams[algorithm]?.forEach((param: AlgorithmParameter) => {
      initParams[param.label.toLowerCase().replace(/ /g, '_')] = param.defaultValue;
    });
    return initParams;
  });

  const toast = useToast();
  const bg = useColorModeValue('gray.50', 'gray.700');
  const inputBg = useColorModeValue('gray.200', 'gray.600');
  const inputColor = useColorModeValue('black', 'white');
  const panelBg = useColorModeValue('white', 'gray.800');

  const handleChange = (value: string | number | boolean, field: string) => {
    setParams({ ...params, [field]: value });
  };

  const handleSave = async () => {
    const endpointMap: {[key: string]: string} = {
      "Linear Regression": 'linear_regression',
      "Polynomial Regression": 'polynomial_regression',
      "Ridge Regression": 'ridge_regression',
      "Lasso Regression": 'lasso_regression',
      "Elastic Net": 'elastic_net',
      "Decision Tree": 'decision_tree',
      "SVR": 'svr',
      "Random Forest": 'random_forest'
    };

    const endpoint = `http://127.0.0.1:8000/ai/${endpointMap[algorithm]}/`;
    const data = { name: algorithm, ...params };

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (response.ok) {
        toast({
          title: 'Parameters saved.',
          description: `Parameters for ${algorithm} have been saved successfully.`,
          status: 'success',
          duration: 5000,
          isClosable: true,
        });
      } else {
        toast({
          title: 'Error',
          description: `Failed to save parameters for ${algorithm}.`,
          status: 'error',
          duration: 5000,
          isClosable: true,
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: `Failed to save parameters for ${algorithm}.`,
        status: 'error',
        duration: 5000,
        isClosable: true,
      });
    }
  };

  return (
    <Box p={6} bg={bg} borderRadius="lg" shadow="md" height="100%" overflowY="auto">
      <VStack spacing={6}>
        <Heading as="h1" size="xl">
          <Icon as={FaRobot} mr={2} />
          {algorithm}
        </Heading>
        
        <Accordion allowToggle defaultIndex={[0]} w="full">
          <AccordionItem>
            <h2>
              <AccordionButton>
                <Box flex="1" textAlign="left" fontSize="lg" fontWeight="bold">
                  <Icon as={FaInfoCircle} mr={2} />
                  How It Works
                </Box>
                <AccordionIcon />
              </AccordionButton>
            </h2>
            <AccordionPanel pb={4} bg={panelBg}>
              <Text>
                {algorithm} is a popular machine learning algorithm. Here's a brief explanation of how it works and why it is used:
              </Text>
              <Text mt={2}>
                {algorithm === "Linear Regression" && "Linear Regression attempts to model the relationship between two variables by fitting a linear equation to observed data."}
                {algorithm === "Polynomial Regression" && "Polynomial Regression is a form of regression analysis in which the relationship between the independent variable x and the dependent variable y is modeled as an nth degree polynomial."}
                {algorithm === "Ridge Regression" && "Ridge Regression is used when data suffers from multicollinearity (independent variables are highly correlated). It adds a degree of bias to the regression estimates, which reduces the standard errors."}
                {algorithm === "Lasso Regression" && "Lasso Regression (Least Absolute Shrinkage and Selection Operator) performs both variable selection and regularization to enhance the prediction accuracy and interpretability of the model."}
                {algorithm === "Elastic Net" && "Elastic Net is a regularized regression method that linearly combines the L1 and L2 penalties of the lasso and ridge methods."}
                {algorithm === "Decision Tree" && "Decision Tree builds a tree-like model of decisions and their possible consequences, including chance event outcomes, resource costs, and utility."}
                {algorithm === "SVR" && "Support Vector Regression (SVR) is a type of Support Vector Machine (SVM) that supports both linear and non-linear regression."}
                {algorithm === "Random Forest" && "Random Forest is an ensemble learning method that operates by constructing multiple decision trees during training and outputting the mode of the classes for classification or mean prediction for regression."}
              </Text>
            </AccordionPanel>
          </AccordionItem>
        </Accordion>

        <Text fontSize="lg">Learn about the parameters and how they affect the algorithm:</Text>
        
        <SimpleGrid columns={[1, null, 2]} spacing={4} w="full">
          {algorithmParams[algorithm]?.map((param: AlgorithmParameter, index: number) => (
            <Box key={index} bg={bg} p={4} borderRadius="md" shadow="sm">
              <FormControl>
                <FormLabel>
                  <Tooltip label={param.description} aria-label={`${param.label} tooltip`}>
                    {param.label}
                  </Tooltip>
                </FormLabel>
                {param.type === "number" ? (
                  <NumberInput 
                    defaultValue={Number(param.defaultValue)} 
                    min={0} 
                    onChange={(valueString, valueNumber) => handleChange(valueNumber, param.label.toLowerCase().replace(/ /g, '_'))}
                  >
                    <NumberInputField bg={inputBg} color={inputColor} />
                  </NumberInput>
                ) : param.type === "boolean" ? (
                  <Checkbox 
                    isChecked={Boolean(params[param.label.toLowerCase().replace(/ /g, '_')])} 
                    onChange={(e) => handleChange(e.target.checked, param.label.toLowerCase().replace(/ /g, '_'))}
                  >
                    {param.label}
                  </Checkbox>
                ) : (
                  <Input 
                    type="text" 
                    defaultValue={String(param.defaultValue)} 
                    bg={inputBg}
                    color={inputColor}
                    onChange={(e) => handleChange(e.target.value, param.label.toLowerCase().replace(/ /g, '_'))}
                  />
                )}
              </FormControl>
              <Alert status="info" mt={2} borderRadius="md">
                <AlertIcon />
                <AlertDescription>{param.description}</AlertDescription>
              </Alert>
            </Box>
          ))}
        </SimpleGrid>

        <Divider />

        <Button colorScheme="blue" onClick={handleSave}>
          <Icon as={FaLightbulb} mr={2} />
          Save Parameters
        </Button>

        <Alert status="success" mt={4} borderRadius="md" variant="left-accent">
          <AlertIcon />
          <AlertDescription>
            Remember to experiment with different values to see how they affect your model's performance!
          </AlertDescription>
        </Alert>
      </VStack>
    </Box>
  );
};

export default AlgorithmDetails;
