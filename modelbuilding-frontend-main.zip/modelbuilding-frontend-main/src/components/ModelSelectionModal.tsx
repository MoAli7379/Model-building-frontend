import React, { useState, useEffect } from 'react';
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  Button,
  Box,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Text,
  useToast,
  Spinner,
  Flex,
  useColorModeValue,
} from '@chakra-ui/react';

interface ModelSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onModelSelect: (model: { id: number; name: string }) => void;
  currentModelPlayer: string | null;
}

interface Model {
  id: number;
  name: string;
  model_type?: string;
  created_at?: string;
  accuracy?: number | null;
}

const ModelSelectionModal: React.FC<ModelSelectionModalProps> = ({ isOpen, onClose, onModelSelect, currentModelPlayer }) => {
  const [models, setModels] = useState<Model[]>([]);
  const [selectedModel, setSelectedModel] = useState<Model | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const toast = useToast();

  useEffect(() => {
    const fetchModels = async () => {
      setIsLoading(true);
      try {
        const response = await fetch('http://127.0.0.1:8000/ai/ai_models');
        const data = await response.json();
        console.log('Fetched Models:', data); // Log the fetched data
        setModels(data);
      } catch (error) {
        console.error('Error fetching models:', error);
        toast({
          title: 'Error',
          description: 'Error fetching models.',
          status: 'error',
          duration: 5000,
          isClosable: true,
        });
      } finally {
        setIsLoading(false);
      }
    };

    if (isOpen) {
      fetchModels();
    }
  }, [isOpen, toast]);

  const handleApply = async () => {
    if (!selectedModel) {
      toast({
        title: 'Error',
        description: 'Please select a model to apply.',
        status: 'error',
        duration: 5000,
        isClosable: true,
      });
      return;
    }

    try {
      await fetch('http://127.0.0.1:8000/ai/update_model/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model_pk: selectedModel.id, player: currentModelPlayer }),
      });
      toast({
        title: 'Success',
        description: 'Model applied successfully!',
        status: 'success',
        duration: 5000,
        isClosable: true,
      });
      onModelSelect(selectedModel);
      onClose();
    } catch (error) {
      console.error('Error applying model:', error);
      toast({
        title: 'Error',
        description: 'Error applying model.',
        status: 'error',
        duration: 5000,
        isClosable: true,
      });
    }
  };

  const hoverBg = useColorModeValue('gray.200', 'gray.600');
  const selectedBg = useColorModeValue('blue.100', 'blue.700');

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="xl">
      <ModalOverlay />
      <ModalContent maxHeight="80vh">
        <ModalHeader>Select a Model</ModalHeader>
        <ModalCloseButton />
        <ModalBody padding={0} overflowY="auto">
          {isLoading ? (
            <Flex justifyContent="center" alignItems="center" height="200px">
              <Spinner size="xl" />
            </Flex>
          ) : models.length === 0 ? (
            <Text mt="4">No models available.</Text>
          ) : (
            <Box maxHeight="60vh" overflowY="auto">
              <Table variant="simple" size="sm">
                <Thead>
                  <Tr>
                    <Th>ID</Th>
                    <Th>Name</Th>
                    <Th>Type</Th>
                    <Th>Created At</Th>
                    <Th>Accuracy</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {models.map((model) => (
                    <Tr
                      key={model.id}
                      onClick={() => setSelectedModel(model)}
                      cursor="pointer"
                      bg={selectedModel?.id === model.id ? selectedBg : ''}
                      _hover={{ bg: hoverBg }}
                    >
                      <Td>{model.id}</Td>
                      <Td>{model.name}</Td>
                      <Td>{model.model_type}</Td>
                      <Td>{new Date(model.created_at || '').toLocaleString()}</Td>
                      <Td>{model.accuracy ? model.accuracy.toFixed(2) : 'N/A'}</Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            </Box>
          )}
        </ModalBody>
        <ModalFooter>
          <Button colorScheme="blue" onClick={handleApply} isDisabled={!selectedModel}>
            Apply
          </Button>
          <Button ml={3} onClick={onClose}>
            Close
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default ModelSelectionModal;
