import React from 'react';
import {
  Box,
  Flex,
  IconButton,
  Text,
  useColorMode,
  useColorModeValue,
  HStack,
  Button,
} from '@chakra-ui/react';
import { FiSun, FiMoon } from 'react-icons/fi';

interface TopNavbarProps {
  onSectionChange: (section: string) => void;
  onTrainClick: () => void;
}

const TopNavbar: React.FC<TopNavbarProps> = ({ onSectionChange, onTrainClick }) => {
  const { colorMode, toggleColorMode } = useColorMode();
  const bgColor = useColorModeValue('white', 'gray.900');
  const textColor = useColorModeValue('black', 'white');

  return (
    <Flex
      as="nav"
      align="center"
      justify="space-between"
      padding="1rem"
      bg={bgColor}
      color={textColor}
      boxShadow="md"
      position="fixed"
      width="100%"
      zIndex="10"
    >
      <Flex align="center">
        <Text fontSize="2xl" fontWeight="bold" ml="2">
          Model Building
        </Text>
      </Flex>
      <HStack spacing="4">
        <Button variant="ghost" onClick={() => onSectionChange('Models')}>Models</Button>
        <Button variant="ghost" onClick={() => onSectionChange('Datasets')}>Datasets</Button>
        <Button colorScheme="teal" onClick={onTrainClick}>Train</Button>
        <IconButton
          aria-label="Toggle color mode"
          icon={colorMode === 'light' ? <FiMoon /> : <FiSun />}
          onClick={toggleColorMode}
        />
      </HStack>
    </Flex>
  );
};

export default TopNavbar;
