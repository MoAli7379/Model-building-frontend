import React, { useState, useEffect } from 'react';
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  Button,
  Select,
  Spinner,
  Box,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Text,
  useToast,
  Flex,
  Checkbox,
  Input,
  useColorModeValue,
} from '@chakra-ui/react';
import axios from 'axios';

interface TrainModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Parameter {
  pk: number;
  param_name: string;
  param_value: string;
  ai_model: number | null;
}

interface ModelResponse {
  id: number;
  name: string;
  intercept?: boolean | null;
  normalize?: boolean | null;
  max_depth?: number | null;
  min_samples_split?: number | null;
  created_at: string;
  updated_at: string;
  parameter: Parameter;
}

interface CsvFile {
  pk: number;
  name: string | null;
  file: string;
}

const TrainModal: React.FC<TrainModalProps> = ({ isOpen, onClose }) => {
  const [step, setStep] = useState(1);
  const [selectedAlgorithm, setSelectedAlgorithm] = useState('');
  const [selectedModel, setSelectedModel] = useState<ModelResponse | null>(null);
  const [modelName, setModelName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isTraining, setIsTraining] = useState(false); // State for training loading indicator
  const [data, setData] = useState<ModelResponse[]>([]);
  const [csvFiles, setCsvFiles] = useState<CsvFile[]>([]);
  const [selectedCsvFiles, setSelectedCsvFiles] = useState<number[]>([]);
  const [selectAll, setSelectAll] = useState(false);
  const toast = useToast();

  useEffect(() => {
    if (selectedAlgorithm) {
      handleFetchData();
    } else {
      setData([]);
    }
  }, [selectedAlgorithm]);

  useEffect(() => {
    if (step === 3) {
      fetchCsvFiles();
    }
  }, [step]);

  useEffect(() => {
    if (selectAll) {
      setSelectedCsvFiles(csvFiles.map(file => file.pk));
    } else {
      setSelectedCsvFiles([]);
    }
  }, [selectAll, csvFiles]);

  const handleAlgorithmChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedAlgorithm(e.target.value);
    setStep(2);
  };

  const handleModelSelection = (model: ModelResponse) => {
    setSelectedModel(model);
    setStep(3);
  };

  const handleCsvFileSelection = (pk: number) => {
    setSelectedCsvFiles((prevSelected) =>
      prevSelected.includes(pk)
        ? prevSelected.filter((id) => id !== pk)
        : [...prevSelected, pk]
    );
  };

  const handleFetchData = async () => {
    setIsLoading(true);
    try {
      const response = await axios.get<ModelResponse[]>(`http://127.0.0.1:8000/ai/${selectedAlgorithm}/`);
      setData(response.data);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchCsvFiles = async () => {
    setIsLoading(true);
    try {
      const response = await axios.get<CsvFile[]>('http://127.0.0.1:8000/api/csv_files/');
      setCsvFiles(response.data);
    } catch (error) {
      console.error('Error fetching CSV files:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleTrainModel = async () => {
    if (selectedCsvFiles.length === 0 || !selectedModel || !modelName) {
      toast({
        title: 'Error',
        description: 'Please select the model, CSV files, and provide a model name to proceed.',
        status: 'error',
        duration: 5000,
        isClosable: true,
      });
      return;
    }
  
    const payload = {
      csv_pks: selectedCsvFiles,
      model_param_pk: selectedModel.parameter.pk,
      model_type: selectedAlgorithm,
      name: modelName,
    };

    setIsTraining(true); // Set training state to true
  
    try {
      await axios.post('http://127.0.0.1:8000/ai/train_model/', payload);
      toast({
        title: 'Success',
        description: 'Model training initiated successfully!',
        status: 'success',
        duration: 5000,
        isClosable: true,
      });
      onClose();
    } catch (error) {
      console.error('Error training model:', error);
      toast({
        title: 'Error',
        description: 'Error training model.',
        status: 'error',
        duration: 5000,
        isClosable: true,
      });
    } finally {
      setIsTraining(false); // Set training state back to false
    }
  };

  const renderAlgorithmSelection = () => (
    <Select placeholder="Select algorithm" onChange={handleAlgorithmChange} mb={4}>
      <option value="linear_regression">Linear Regression</option>
      <option value="polynomial_regression">Polynomial Regression</option>
      <option value="ridge_regression">Ridge Regression</option>
      <option value="lasso_regression">Lasso Regression</option>
      <option value="elastic_net">Elastic Net</option>
      <option value="decision_tree">Decision Tree</option>
      <option value="svr">SVR</option>
      <option value="random_forest">Random Forest</option>
    </Select>
  );

  const hoverBg = useColorModeValue('gray.200', 'gray.600');

  const renderModelSelection = () => {
    if (isLoading) {
      return (
        <Box display="flex" justifyContent="center" alignItems="center">
          <Spinner size="xl" />
        </Box>
      );
    }

    if (data.length === 0) {
      return <Text mt="4">No models available for the selected algorithm.</Text>;
    }

    return (
      <Box mt="4" maxHeight="400px" overflowY="auto">
        <Table variant="simple" size="sm">
          <Thead>
            <Tr>
              <Th>ID</Th>
              <Th>Name</Th>
              <Th>Parameters</Th>
              <Th>Created At</Th>
              <Th>Updated At</Th>
            </Tr>
          </Thead>
          <Tbody>
            {data.map((item) => (
              <Tr key={item.id} onClick={() => handleModelSelection(item)} cursor="pointer" _hover={{ bg: hoverBg }}>
                <Td>{item.id}</Td>
                <Td>{item.name}</Td>
                <Td>{item.parameter.pk}</Td>
                <Td>{new Date(item.created_at).toLocaleString()}</Td>
                <Td>{new Date(item.updated_at).toLocaleString()}</Td>
              </Tr>
            ))}
          </Tbody>
        </Table>
      </Box>
    );
  };

  const renderCsvSelection = () => {
    if (isLoading) {
      return (
        <Box display="flex" justifyContent="center" alignItems="center">
          <Spinner size="xl" />
        </Box>
      );
    }

    return (
      <Box mt="4" maxHeight="400px" overflowY="auto">
        <Table variant="simple" size="sm">
          <Thead>
            <Tr>
              <Th>
                <Checkbox isChecked={selectAll} onChange={() => setSelectAll(!selectAll)}>
                  Select All
                </Checkbox>
              </Th>
              <Th>File</Th>
            </Tr>
          </Thead>
          <Tbody>
            {csvFiles.map((file) => (
              <Tr key={file.pk} _hover={{ bg: hoverBg }}>
                <Td>
                  <Checkbox isChecked={selectedCsvFiles.includes(file.pk)} onChange={() => handleCsvFileSelection(file.pk)} />
                </Td>
                <Td>{file.file}</Td>
              </Tr>
            ))}
          </Tbody>
        </Table>
      </Box>
    );
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="xl">
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Train Model</ModalHeader>
        <ModalCloseButton />
        <ModalBody>
          {step === 1 && renderAlgorithmSelection()}
          {step === 2 && renderModelSelection()}
          {step === 3 && (
            <>
              <Input
                placeholder="Enter model name"
                value={modelName}
                onChange={(e) => setModelName(e.target.value)}
                mb={4}
              />
              {renderCsvSelection()}
            </>
          )}
        </ModalBody>
        <ModalFooter>
          <Flex justify="space-between" w="100%">
            {step > 1 && <Button onClick={() => setStep(step - 1)}>Back</Button>}
            {step < 3 && <Button ml={3} onClick={() => setStep(step + 1)}>Next</Button>}
            {step === 3 && (
              <Button colorScheme="blue" onClick={handleTrainModel} isLoading={isTraining}> {/* Show loading spinner when training */}
                Train Model
              </Button>
            )}
            <Button ml={3} onClick={onClose}>Close</Button>
          </Flex>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default TrainModal;
