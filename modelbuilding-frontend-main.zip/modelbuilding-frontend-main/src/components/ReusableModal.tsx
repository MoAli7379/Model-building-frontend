// src/components/ReusableModal.tsx
import React, { useEffect, useState } from 'react';
import {
  Modal, ModalOverlay, ModalContent, ModalHeader, ModalCloseButton, ModalBody,
  ModalFooter, Button, Table, Thead, Tbody, Tr, Th, Td, Text, Box, Spinner
} from '@chakra-ui/react';
import { fetchData } from '../utils/api';

interface ReusableModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  endpoint: string;  // Endpoint to fetch data from
  config: { label: string; field: string }[];  // Configuration for how to display the data
}

const ReusableModal: React.FC<ReusableModalProps> = ({ isOpen, onClose, title, endpoint, config }) => {
  const [data, setData] = useState<any[] | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && endpoint) {
      setLoading(true);
      fetchData(endpoint)
        .then(response => {
          setData(Array.isArray(response) ? response : [response]);  // Handle both single object and array responses
          setLoading(false);
        })
        .catch(err => {
          setError(err.message);
          setLoading(false);
        });
    } else if (!isOpen) {
      setData(null);  // Clear data when modal closes
      setError(null);  // Clear errors when modal closes
    }
  }, [isOpen, endpoint]);

  const renderTableHeader = () => (
    <Thead>
      <Tr>
        {config.map((item, index) => <Th key={index}>{item.label}</Th>)}
      </Tr>
    </Thead>
  );

  const renderTableBody = () => {
    if (!data) return null;  // Check for null data before attempting to map
    return (
      <Tbody>
        {data.map((row, rowIndex) => (
          <Tr key={rowIndex}>
            {config.map((col, colIndex) => (
              <Td key={colIndex}>{row[col.field]}</Td>
            ))}
          </Tr>
        ))}
      </Tbody>
    );
  };

  const renderData = () => {
    if (loading) return <Box display="flex" justifyContent="center" p="4"><Spinner /></Box>;
    if (error) return <Box p="4" color="red.500">{error}</Box>;
    if (!data || data.length === 0) return <Box p="4">No data available</Box>;

    return (
      <Box overflowX="auto">
        <Table variant="simple" size="sm">
          {renderTableHeader()}
          {renderTableBody()}
        </Table>
      </Box>
    );
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} closeOnOverlayClick={false} size="3xl">
      <ModalOverlay />
      <ModalContent maxW="80%">
        <ModalHeader>{title}</ModalHeader>
        <ModalCloseButton />
        <ModalBody>
          {renderData()}
        </ModalBody>
        <ModalFooter>
          <Button colorScheme="blue" onClick={onClose}>Close</Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default ReusableModal;
