import React from 'react';
import { Box, useColorModeValue } from '@chakra-ui/react';
import CsvFilesPage from '../pages/CsvFilesPage';
import ModelPage from '../pages/ModelPage';
import AlgorithmDetails from './AlgorithmDetails';
import UnityGame from './UnityGame';

interface MainContentProps {
  activeSection: string;
  handleModelSelect: (model: { id: number; name: string }) => void;
  model: { id: number; name: string } | null;
  showGame: boolean;
}

const MainContent: React.FC<MainContentProps> = ({ activeSection, model, handleModelSelect, showGame }) => {
  const bgColor = useColorModeValue('gray.100', 'gray.900');
  const textColor = useColorModeValue('black', 'white');
  const defaultBgColor = useColorModeValue('gray.50', 'gray.800');

  const renderContent = () => {
    if (showGame) {
      return <UnityGame />;
    }

    switch (activeSection) {
      case 'Datasets':
        return <CsvFilesPage />;
      case 'Models':
        return <ModelPage onModelSelect={handleModelSelect} />;
      case 'Linear Regression':
      case 'Polynomial Regression':
      case 'Ridge Regression':
      case 'Lasso Regression':
      case 'Elastic Net':
      case 'Decision Tree':
      case 'SVR':
      case 'Random Forest':
        return <AlgorithmDetails algorithm={activeSection} />;
      default:
        return (
          <Box
            flex="1"
            display="flex"
            alignItems="center"
            justifyContent="center"
            bg={defaultBgColor}
            color={textColor}
            borderRadius="md"
            boxShadow="md"
            textAlign="center"
            height="100%"
          >
            Select an item from the sidebar.
          </Box>
        );
    }
  };

  return (
    <Box flex="1" p="5" bg={bgColor} height="100%">
      {renderContent()}
    </Box>
  );
};

export default MainContent;
