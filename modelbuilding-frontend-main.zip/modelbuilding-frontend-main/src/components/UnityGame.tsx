import React from 'react';
import { Unity, useUnityContext } from 'react-unity-webgl';

const UnityGame = () => {
  const { unityProvider, loadingProgression, isLoaded } = useUnityContext({
    loaderUrl: "/unity/Build/lastb.loader.js",
    dataUrl: "/unity/Build/lastb.data",
    frameworkUrl: "/unity/Build/lastb.framework.js",
    codeUrl: "/unity/Build/lastb.wasm",
  });

  return (
    <div>
      {!isLoaded && <p>Loading... {Math.round(loadingProgression * 100)}%</p>}
      <Unity unityProvider={unityProvider} style={{ width: '960px', height: '600px' }} />
    </div>
  );
};

export default UnityGame;
