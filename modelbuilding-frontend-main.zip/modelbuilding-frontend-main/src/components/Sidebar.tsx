import React, { ReactNode } from 'react';
import {
  Box,
  Flex,
  Icon,
  Link,
  Drawer,
  DrawerContent,
  Text,
  useDisclosure,
  BoxProps,
  FlexProps,
  VStack,
  useColorModeValue,
} from '@chakra-ui/react';
import { FiTrendingUp, FiMenu } from 'react-icons/fi';
import { IconType } from 'react-icons';

interface LinkItemProps {
  name: string;
  icon: IconType;
  onClick: () => void;
}

interface SidebarProps {
  onSectionChange: (section: string) => void;
  children?: ReactNode;
}

const SimpleSidebar: React.FC<SidebarProps> = ({ children, onSectionChange }) => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const bgColor = useColorModeValue('gray.100', 'gray.900');
  const textColor = useColorModeValue('black', 'white');

  const LinkItems: Array<LinkItemProps> = [
    { name: 'Linear Regression', icon: FiTrendingUp, onClick: () => onSectionChange('Linear Regression') },
    { name: 'Polynomial Regression', icon: FiTrendingUp, onClick: () => onSectionChange('Polynomial Regression') },
    { name: 'Ridge Regression', icon: FiTrendingUp, onClick: () => onSectionChange('Ridge Regression') },
    { name: 'Lasso Regression', icon: FiTrendingUp, onClick: () => onSectionChange('Lasso Regression') },
    { name: 'Elastic Net', icon: FiTrendingUp, onClick: () => onSectionChange('Elastic Net') },
    { name: 'Decision Tree', icon: FiTrendingUp, onClick: () => onSectionChange('Decision Tree') },
    { name: 'SVR', icon: FiTrendingUp, onClick: () => onSectionChange('SVR') },
    { name: 'Random Forest', icon: FiTrendingUp, onClick: () => onSectionChange('Random Forest') },
  ];

  return (
    <Box minH="100vh" bg={bgColor} color={textColor}>
      <SidebarContent onClose={onClose} display={{ base: 'none', md: 'block' }} LinkItems={LinkItems} />
      <Drawer autoFocus={false} isOpen={isOpen} placement="left" onClose={onClose} returnFocusOnClose={false} onOverlayClick={onClose} size="full">
        <DrawerContent>
          <SidebarContent onClose={onClose} LinkItems={LinkItems} />
        </DrawerContent>
      </Drawer>
      <Box ml={{ base: 0, md: 60 }} p="4">
        {children}
      </Box>
    </Box>
  );
};

interface SidebarContentProps extends BoxProps {
  onClose: () => void;
  LinkItems: Array<LinkItemProps>;
}

const SidebarContent = ({ onClose, LinkItems, ...rest }: SidebarContentProps) => {
  const bgColor = useColorModeValue('gray.100', 'gray.900');

  return (
    <Box
      bg={bgColor}
      borderRight="1px"
      borderRightColor={useColorModeValue('gray.200', 'gray.700')}
      w={{ base: 'full', md: 60 }}
      pos="fixed"
      h="full"
      {...rest}
    >
      <Flex h="20" alignItems="center" mx="8" justifyContent="space-between">
        <Text fontSize="2xl" fontFamily="monospace" fontWeight="bold">
          Algorithms
        </Text>
      </Flex>
      <VStack align="stretch" spacing="1">
        {LinkItems.map((link) => (
          <NavItem key={link.name} icon={link.icon} onClick={link.onClick}>
            {link.name}
          </NavItem>
        ))}
      </VStack>
    </Box>
  );
};

interface NavItemProps extends FlexProps {
  icon: IconType;
  children: React.ReactNode;
  onClick: () => void;
}

const NavItem = ({ icon, children, onClick, ...rest }: NavItemProps) => {
  return (
    <Link href="#" onClick={onClick} style={{ textDecoration: 'none' }} _focus={{ boxShadow: 'none' }}>
      <Flex
        align="center"
        p="4"
        mx="4"
        borderRadius="lg"
        role="group"
        cursor="pointer"
        _hover={{
          bg: 'cyan.400',
          color: 'white',
        }}
        {...rest}
      >
        {icon && (
          <Icon
            mr="4"
            fontSize="16"
            _groupHover={{
              color: 'white',
            }}
            as={icon}
          />
        )}
        {children}
      </Flex>
    </Link>
  );
};

export default SimpleSidebar;
