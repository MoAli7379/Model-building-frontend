import React, { useEffect, useState } from 'react';
import TableHeader from './TableHeader';
import TableRow from './TableRow';
import Loader from './Loader';
import Error from './Error';
import { fetchData } from '../../utils/api';

interface DataTableProps {
  endpoint: string;
  columns: Array<{
    label: string;
    field: string;
  }>;
}

const DataTable = ({ endpoint, columns }: DataTableProps) => {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchData(endpoint)
      .then(response => {
        setData(response);
        setLoading(false);
      })
      .catch(err => {
        setError(err.message);
        setLoading(false);
      });
  }, [endpoint]);

  if (loading) return <Loader />;
  if (error) return <Error message={error} />;

  return (
    <table>
      <TableHeader columns={columns} />
      <tbody>
        {data.map((item, index) => (
          <TableRow key={index} data={item} columns={columns} />
        ))}
      </tbody>
    </table>
  );
};

export default DataTable;
