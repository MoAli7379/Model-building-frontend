import React from 'react';

interface TableHeaderProps {
  columns: Array<{ label: string; field: string }>;
}

const TableHeader: React.FC<TableHeaderProps> = ({ columns }) => {
  return (
    <thead>
      <tr>
        {columns.map((col, index) => (
          <th key={index}>{col.label}</th>
        ))}
      </tr>
    </thead>
  );
};

export default TableHeader;
