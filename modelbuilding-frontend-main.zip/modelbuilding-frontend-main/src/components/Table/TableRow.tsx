import React from 'react';
import TableCell from './TableCell';

interface TableRowProps {
  data: { [key: string]: any };
  columns: Array<{ label: string; field: string }>;
}

const TableRow: React.FC<TableRowProps> = ({ data, columns }) => {
  return (
    <tr>
      {columns.map((col, index) => (
        <TableCell key={index}>{data[col.field]}</TableCell>
      ))}
    </tr>
  );
};

export default TableRow;
