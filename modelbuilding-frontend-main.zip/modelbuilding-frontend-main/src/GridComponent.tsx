import React, { useEffect, useState } from 'react';
import {
  Box,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Spinner,
  Text,
  useColorModeValue,
} from '@chakra-ui/react';
import { fetchData } from './utils/api';

interface ColumnDef {
  label: string;
  field: string;
}

interface GridComponentProps {
  endpoint: string;
  columns: ColumnDef[];
  onRowSelection: (selectedRows: any[]) => void;
}

const GridComponent: React.FC<GridComponentProps> = ({ endpoint, columns, onRowSelection }) => {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedRows, setSelectedRows] = useState<any[]>([]);
  const bgColor = useColorModeValue('white', 'gray.800');
  const textColor = useColorModeValue('black', 'white');
  const hoverColor = useColorModeValue('teal.100', 'teal.700');

  useEffect(() => {
    fetchData(endpoint)
      .then((response) => {
        setData(response);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, [endpoint]);

  const handleRowSelection = (item: any) => {
    const isSelected = selectedRows.includes(item);
    const newSelectedRows = isSelected
      ? selectedRows.filter((row) => row !== item)
      : [...selectedRows, item];

    setSelectedRows(newSelectedRows);
    onRowSelection(newSelectedRows);
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
        <Spinner size="xl" />
      </Box>
    );
  }

  if (error) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
        <Text color="red.500">{error}</Text>
      </Box>
    );
  }

  return (
    <Box overflowX="auto" p={4} bg={bgColor} color={textColor} height="100%">
      <Table variant="simple">
        <Thead>
          <Tr>
            {columns.map((col) => (
              <Th key={col.field}>{col.label}</Th>
            ))}
          </Tr>
        </Thead>
        <Tbody>
          {data.map((item, rowIndex) => (
            <Tr
              key={rowIndex}
              cursor="pointer"
              _hover={{ bg: hoverColor }}
              onClick={() => handleRowSelection(item)}
            >
              {columns.map((col) => (
                <Td key={col.field}>{item[col.field]}</Td>
              ))}
            </Tr>
          ))}
        </Tbody>
      </Table>
    </Box>
  );
};

export default GridComponent;
