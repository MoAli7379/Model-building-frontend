// src/utils/api.ts
const API_BASE_URL = process.env.REACT_APP_API_BASE_URL;
console.log('API_BASE_URL:', API_BASE_URL);

export const fetchData = async (endpoint: string) => {
  try {
    if (!API_BASE_URL) {
      throw new Error('API_BASE_URL is not defined');
    }

    const url = `${API_BASE_URL}${endpoint}`;
    console.log('Fetching data from URL:', url);

    const response = await fetch(url);
    const contentType = response.headers.get('content-type');

    if (!response.ok) {
      throw new Error(`Network response was not ok: ${response.statusText}`);
    }

    if (contentType && contentType.includes('application/json')) {
      return response.json();
    } else {
      const text = await response.text();
      throw new Error(`Expected JSON but got: ${text}`);
    }
  } catch (error) {
    console.error('Fetch data error:', error);
    throw error;
  }
};
