interface Window {
    UnityLoader: {
      instantiate: (id: string, url: string, options: any) => void;
    };
  }
  
  declare var UnityProgress: any;
  