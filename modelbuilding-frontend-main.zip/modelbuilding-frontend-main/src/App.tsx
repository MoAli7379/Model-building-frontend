import React, { useState } from 'react';
import { ChakraProvider, Flex, Box, Button, useColorModeValue } from '@chakra-ui/react';
import Sidebar from './components/Sidebar';
import MainContent from './components/MainContent';
import TrainModal from './components/TrainModal';
import GameConfigModal from './components/GameConfigModal';
import TopNavbar from './components/TopNavbar';

const App = () => {
  const [activeSection, setActiveSection] = useState<string>('');
  const [selectedModel, setSelectedModel] = useState<{ id: number; name: string } | null>(null);
  const [showGame, setShowGame] = useState(false);
  const [isTrainModalOpen, setTrainModalOpen] = useState(false);
  const [isGameConfigModalOpen, setGameConfigModalOpen] = useState(false);
  const bgColor = useColorModeValue('gray.50', 'gray.800');

  const handleSectionChange = (section: string) => {
    setActiveSection(section);
    setShowGame(false);
  };

  const handleModelSelect = (model: { id: number; name: string }) => {
    setSelectedModel(model);
    setActiveSection('modelDetails');
    setShowGame(false);
  };

  const handlePlayButtonClick = () => {
    setActiveSection('');
    setGameConfigModalOpen(true);
  };

  const handleConfigApply = async (config: {
    player_white: string;
    player_black: string;
    save_data: boolean;
    model_white?: { id: number; name: string };
    model_black?: { id: number; name: string };
  }) => {
    console.log('Game Config:', config);
    try {
      if (config.player_white === 'Model' && config.model_white) {
        await fetch('http://127.0.0.1:8000/ai/update_model/', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ model_pk: config.model_white.id, player: 'white' }),
        });
      }
      if (config.player_black === 'Model' && config.model_black) {
        await fetch('http://127.0.0.1:8000/ai/update_model/', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ model_pk: config.model_black.id, player: 'black' }),
        });
      }
      await fetch('http://127.0.0.1:8000/ai/config/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          player_white: config.player_white,
          player_black: config.player_black,
          save_data: config.save_data,
        }),
      });
      setShowGame(true);
      setGameConfigModalOpen(false);
    } catch (error) {
      console.error('Error applying configuration:', error);
    }
  };

  return (
    <ChakraProvider>
      <Flex direction="column" height="100vh" overflow="hidden" bg={bgColor}>
        <TopNavbar onSectionChange={handleSectionChange} onTrainClick={() => setTrainModalOpen(true)} />
        <Flex direction="row" flex="1" overflow="hidden" pt="70px">
          <Sidebar onSectionChange={handleSectionChange} />
          <Box flex="1" overflow="auto" bg={bgColor}>
            <MainContent
              activeSection={activeSection}
              handleModelSelect={handleModelSelect}
              model={selectedModel}
              showGame={showGame}
            />
          </Box>
        </Flex>
        <Button
          onClick={handlePlayButtonClick}
          position="fixed"
          bottom="20px"
          right="20px"
          colorScheme="teal"
          size="lg"
          borderRadius="full"
          shadow="lg"
        >
          Play
        </Button>
      </Flex>
      <TrainModal isOpen={isTrainModalOpen} onClose={() => setTrainModalOpen(false)} />
      <GameConfigModal
        isOpen={isGameConfigModalOpen}
        onClose={() => setGameConfigModalOpen(false)}
        onConfigApply={handleConfigApply}
      />
    </ChakraProvider>
  );
};

export default App;
